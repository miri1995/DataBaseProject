package com.example.dana160193.myfirstapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;



public class Main3Activity extends AppCompatActivity {

    Filters filter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent1 = getIntent();
        if (intent1.hasExtra("com.example.dana160193.myfirstapp.Filters")) {
            filter = (Filters) intent1.getSerializableExtra("com.example.dana160193.myfirstapp.Filters");
        }

        String[] resultArray = {"result1","result2","result3","result4",
                "result5"};
        //ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.activity_main3, resultArray);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.activity_list_item, android.R.id.text1, resultArray);
        ListView listView = findViewById(R.id.result_list);
        listView.setAdapter(adapter);



    }

    public void back_click(View view) {
        Intent intent = new Intent(Main3Activity.this, Main2Activity.class);
        startActivity(intent);
    }

}
